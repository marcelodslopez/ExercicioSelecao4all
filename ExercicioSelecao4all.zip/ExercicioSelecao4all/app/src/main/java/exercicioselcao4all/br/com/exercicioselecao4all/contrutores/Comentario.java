package exercicioselcao4all.br.com.exercicioselecao4all.contrutores;

import java.io.Serializable;

/**
 * Created by Marcelo on 04/06/2016.
 */
public class Comentario implements Serializable{
    String urlFoto;
    String nome;
    int nota;
    String titulo;
    String comentario;


    public Comentario() {

    }

    public String getUrlFoto() {
        return urlFoto;
    }

    public void setUrlFoto(String urlFoto) {
        this.urlFoto = urlFoto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
}
