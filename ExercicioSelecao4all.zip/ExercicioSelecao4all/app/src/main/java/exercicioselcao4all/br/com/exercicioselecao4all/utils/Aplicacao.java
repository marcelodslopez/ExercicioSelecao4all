package exercicioselcao4all.br.com.exercicioselecao4all.utils;

import java.util.ArrayList;
import java.util.List;

import exercicioselcao4all.br.com.exercicioselecao4all.contrutores.Tarefa;

/**
 * Created by marcelo on 08/06/2016.
 */
public class Aplicacao {
    public static List<String> listaIds;
    public static List<Tarefa> listaTarefas = new ArrayList<Tarefa>();

}
