package exercicioselcao4all.br.com.exercicioselecao4all.utils;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import exercicioselcao4all.br.com.exercicioselecao4all.R;

/**
 * Created by Marcelo on 04/06/2016.
 * Classe de utilitários
 */
public class Utils {

    /**
     * Método para obtenção de Json de um webService
     * @param url string
     * @return JSONObject
     */
    public static JSONObject getJsonWebService(String url){
        JSONObject jsonObject = null;
        HttpClient httpclient = new DefaultHttpClient();
        HttpGet httpget = new HttpGet(url);
        try {
            HttpResponse response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                InputStream instream = entity.getContent();
                String retorno = getStringFromInputStream(instream);
                jsonObject = new JSONObject(retorno);
                instream.close();
            }
        } catch (Exception e) {
            Log.e("Erro", "Falha ao acessar Web service", e);
        }
        return jsonObject;
    }

    /**
     * Método para converter objeto InputStream para String
     * @param inputStream  - InputStream
     * @return String
     */
    private static String getStringFromInputStream(InputStream inputStream) {

        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();

        String line;
        try {

            br = new BufferedReader(new InputStreamReader(inputStream));
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return sb.toString();

    }

    /**
     * Método para exibição de um Toast na tela - short
     * @param contexto contexto
     * @param msg string
     * @return void
     */
    public static void showToast(final Context contexto, final String msg) {
        // mostra o Toast
        Toast.makeText(contexto, msg, Toast.LENGTH_SHORT).show();
    }


}
