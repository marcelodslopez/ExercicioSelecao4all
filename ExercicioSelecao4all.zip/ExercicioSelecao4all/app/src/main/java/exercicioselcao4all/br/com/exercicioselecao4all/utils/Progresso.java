package exercicioselcao4all.br.com.exercicioselecao4all.utils;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import exercicioselcao4all.br.com.exercicioselecao4all.R;

/**
 * Created by Marcelo on 04/06/2016.
 */
public class Progresso extends LinearLayout {
	private TextView texto;

	/**
	 * Constructor
	 */
	public Progresso(final Context context)                     { super(context);       init(context); }
	public Progresso(final Context context, AttributeSet attrs) { super(context,attrs); init(context); }

	/**
	 * Metodo de inicializacao
	 * 
	 * @param context
	 */
	private void init(Context context) {
		// seta o Background
		setBackgroundColor(getResources().getColor(R.color.transparent));

		// pega o inflater
		final LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		// pega a View
		final View view = inflater.inflate(R.layout.progresso, this);
		
		// pega o texto
		texto = (TextView) view.findViewById(R.id.textoProgressoDefault);
	}

	/**
	 * Metodos para mostrar/inibir o Progresso
	 */
	public void hide()           {                     setVisibility(View.INVISIBLE); }
	public void show()           {                     setVisibility(View.VISIBLE);   }
	public void show(String txt) { texto.setText(txt); setVisibility(View.VISIBLE);   }
	public void show(int txt)    { texto.setText(txt); setVisibility(View.VISIBLE);   }
}