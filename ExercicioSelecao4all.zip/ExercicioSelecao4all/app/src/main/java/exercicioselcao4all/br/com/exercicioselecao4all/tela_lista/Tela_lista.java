package exercicioselcao4all.br.com.exercicioselecao4all.tela_lista;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import exercicioselcao4all.br.com.exercicioselecao4all.R;
import exercicioselcao4all.br.com.exercicioselecao4all.contrutores.Comentario;
import exercicioselcao4all.br.com.exercicioselecao4all.contrutores.Tarefa;
import exercicioselcao4all.br.com.exercicioselecao4all.tela_principal.TelaPrincipal;
import exercicioselcao4all.br.com.exercicioselecao4all.utils.Aplicacao;
import exercicioselcao4all.br.com.exercicioselecao4all.utils.Progresso;
import exercicioselcao4all.br.com.exercicioselecao4all.utils.Utils;


public class Tela_lista extends AppCompatActivity {

    ListView tela_lista_lvTarefas;
    Progresso tela_lista_progressBar;
    TextView toolbar_title_list;
    List<String> listaIds = new ArrayList<String>();
    boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_lista);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_lista);
        setSupportActionBar(toolbar);

        Window window = Tela_lista.this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(Tela_lista.this.getResources().getColor(R.color.colorPrimary));
        }

        tela_lista_lvTarefas = (ListView) findViewById(R.id.tela_lista_lvTarefas);
        tela_lista_progressBar = (Progresso) findViewById(R.id.tela_lista_progressBar);

        toolbar_title_list = (TextView) toolbar.findViewById(R.id.toolbar_title_list);
        toolbar_title_list.setText("Lista de tarefas");

        if (Aplicacao.listaIds == null){
            new buscarWSLista(getApplicationContext(), "http://dev.4all.com:3003/tarefa/").execute();
        }else{
            AdapterLista adapterLista = new AdapterLista(getBaseContext());
            adapterLista.setLista(Aplicacao.listaIds);
            tela_lista_lvTarefas.setAdapter(adapterLista);
            adapterLista.notifyDataSetChanged();

            tela_lista_lvTarefas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    boolean achou = false;
                    Tarefa tarefaEcontrada = null;
                    //se achar a tarefa na memória, não precisa buscar ela no webservice, carrega direto a tela
                    for (int i=0; i< Aplicacao.listaTarefas.size();i++){
                        if (Aplicacao.listaTarefas.get(i).getId().equals(Aplicacao.listaIds.get(position))){
                           achou = true;
                            tarefaEcontrada = Aplicacao.listaTarefas.get(i);
                            break;
                        }
                    }
                    if (achou){
                        Intent intent = new Intent(getBaseContext(), TelaPrincipal.class);
                        intent.putExtra("tarefa", tarefaEcontrada);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
                        finish();
                    }else{
                        //não achou na memória, busca no Ws
                        new buscarWSTarefa(getApplicationContext(), "http://dev.4all.com:3003/tarefa/", Aplicacao.listaIds.get(position)).execute();
                    }
                }
            });

        }

    }

    //Método para buscar a lista de taregas do webService e prencher a lista da tela
    private class buscarWSLista extends AsyncTask<Void, Void, Void> {

        JSONObject jsonObject;
        Context context;
        String URL;

        public buscarWSLista(Context context, String URL) {
            this.context = context;
            this.URL = URL;
        }


        @Override
        protected void onPreExecute() {

            tela_lista_progressBar.show(R.string.aguarde_carregamento);
            tela_lista_progressBar.setVisibility(View.VISIBLE);
            tela_lista_lvTarefas.setVisibility(View.GONE);
        }

        @Override
        protected Void doInBackground(Void... params) {

            jsonObject = Utils.getJsonWebService(URL);
            return null;

        }


        @Override
        protected void onPostExecute(Void result) {
            if(jsonObject !=null){
                try {
                    JSONArray jsonArray_ids = jsonObject.getJSONArray("lista");

                    for (int i=0;i<jsonArray_ids.length();i++){
                        listaIds.add(jsonArray_ids.get(i).toString());
                    }

                    AdapterLista adapterLista = new AdapterLista(getBaseContext());
                    adapterLista.setLista(listaIds);
                    tela_lista_lvTarefas.setAdapter(adapterLista);
                    adapterLista.notifyDataSetChanged();

                    Aplicacao.listaIds =listaIds;

                    tela_lista_progressBar.setVisibility(View.GONE);
                    tela_lista_lvTarefas.setVisibility(View.VISIBLE);

                    tela_lista_lvTarefas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            boolean achou = false;
                            Tarefa tarefaEncontrada=null;
                            //Procura a tarefa na memória pre-carregada.
                            for (int i=0; i< Aplicacao.listaTarefas.size();i++){
                                if (Aplicacao.listaTarefas.get(i).getId().equals(Aplicacao.listaIds.get(position))){
                                   achou = true;
                                    tarefaEncontrada =  Aplicacao.listaTarefas.get(i);
                                    break;
                                }
                            }

                            //se achou  a tarefa carrega direto a tela se não busca no Ws
                            if (achou){
                                Intent intent = new Intent(getBaseContext(), TelaPrincipal.class);
                                intent.putExtra("tarefa",tarefaEncontrada);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
                                finish();
                            }else{
                                new buscarWSTarefa(getApplicationContext(), URL, listaIds.get(position)).execute();
                            }


                        }
                    });

                } catch (JSONException e) {
                    tela_lista_progressBar.setVisibility(View.GONE);
                    tela_lista_lvTarefas.setVisibility(View.VISIBLE);
                    e.printStackTrace();
                }

            }else{
                tela_lista_progressBar.setVisibility(View.GONE);
                tela_lista_lvTarefas.setVisibility(View.VISIBLE);
            }
            tela_lista_progressBar.setVisibility(View.GONE);
            tela_lista_lvTarefas.setVisibility(View.VISIBLE);
            super.onPostExecute(result);
      }

    }

    //Método para buscar a tarefa escolhida do webService e logo direcionar para a tela principal
    private class buscarWSTarefa extends AsyncTask<Void, Void, Void> {

        JSONObject jsonObject;
        Context context;
        String URL;

        public buscarWSTarefa(Context context, String URL, String tarefa) {
            this.context = context;
            this.URL = URL+tarefa;
        }


        @Override
        protected void onPreExecute() {

            tela_lista_progressBar.show(R.string.aguarde_carregamento);
            tela_lista_progressBar.setVisibility(View.VISIBLE);
            tela_lista_lvTarefas.setVisibility(View.GONE);
        }

        @Override
        protected Void doInBackground(Void... params) {

            jsonObject = Utils.getJsonWebService(URL);
            return null;
        }


        @Override
        protected void onPostExecute(Void result) {
            if(jsonObject !=null){
                //Monta o objeto tarefa
                Tarefa tarefa = new Tarefa();
                try {
                    tarefa.setId(jsonObject.getString("id"));
                    tarefa.setCidade(jsonObject.getString("cidade"));
                    tarefa.setBairro(jsonObject.getString("bairro"));
                    tarefa.setUrlFoto(jsonObject.getString("urlFoto"));
                    tarefa.setUrlLogo(jsonObject.getString("urlLogo"));
                    tarefa.setTitulo(jsonObject.getString("titulo"));
                    tarefa.setTelefone(jsonObject.getString("telefone"));
                    tarefa.setTexto(jsonObject.getString("texto"));
                    tarefa.setEndereco(jsonObject.getString("endereco"));
                    tarefa.setLatitude(jsonObject.getDouble("latitude"));
                    tarefa.setLongitude(jsonObject.getDouble("longitude"));

                    List<Comentario> comentarios = new ArrayList<Comentario>();
                    JSONArray jsonArray_comentarios = jsonObject.getJSONArray("comentarios");

                    //monta o array de comentários
                    for (int i=0; i< jsonArray_comentarios.length();i++){
                        JSONObject jsonObject = new JSONObject(jsonArray_comentarios.get(i).toString());
                        Comentario comentario = new Comentario();
                        comentario.setUrlFoto(jsonObject.getString("urlFoto"));
                        comentario.setNome(jsonObject.getString("nome"));
                        comentario.setNota(jsonObject.getInt("nota"));
                        comentario.setTitulo(jsonObject.getString("titulo"));
                        comentario.setComentario(jsonObject.getString("comentario"));

                        comentarios.add(comentario );
                    }
                    tarefa.setComentarios(comentarios);

                    //inicia a atividade de tela inicial passando o objeto tarefa serializado
                    Intent intent = new Intent(getBaseContext(), TelaPrincipal.class);
                    intent.putExtra("tarefa", tarefa);
                    //Insere a tarefa no carregamento em memória.
                    Aplicacao.listaTarefas.add(tarefa);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
                    tela_lista_progressBar.setVisibility(View.GONE);
                    finish();

                } catch (JSONException e) {
                    e.printStackTrace();
                    Utils.showToast(Tela_lista.this, getResources().getString(R.string.erro_montar_tarefa));
                    tela_lista_progressBar.setVisibility(View.GONE);
                    tela_lista_lvTarefas.setVisibility(View.VISIBLE);
                }

            }else{
                Utils.showToast(Tela_lista.this, getResources().getString(R.string.erro_montar_webservice));
                tela_lista_progressBar.setVisibility(View.GONE);
                tela_lista_lvTarefas.setVisibility(View.VISIBLE);
            }
            tela_lista_progressBar.setVisibility(View.GONE);
            super.onPostExecute(result);
        }


    }

    @Override
    public void onBackPressed() {
        //Se pressionou o botão back duas vezes sai da aplicacao
        if (doubleBackToExitPressedOnce) {
            System.exit(0);
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Utils.showToast(Tela_lista.this, getResources().getString(R.string.aviso_sair));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

}
