package exercicioselcao4all.br.com.exercicioselecao4all.tela_lista;

import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

import exercicioselcao4all.br.com.exercicioselecao4all.R;

/**
 * Created by Marcelo on 04/06/2016.
 */
public class AdapterLista  extends BaseAdapter {
    List<String> listaIds;
    LayoutInflater layoutInflater;
    Context context;

    public AdapterLista(Context context) {
        this.context = context;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    //Metodo para setar a lista no adapter
    public void setLista(List<String> listaIds) {
        this.listaIds = listaIds;
        this.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return listaIds.size();
    }

    @Override
    public Object getItem(int i) {
        return listaIds.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }


    @Override
    public View getView(int position, View contextView, ViewGroup viewGroup) {
        RelativeLayout layout = (RelativeLayout) contextView;
        ViewHolder view;

        if (layout == null) {

            layout = (RelativeLayout) layoutInflater.inflate(R.layout.adapter_list, null);

            view = new ViewHolder();

            view.texto =                   (TextView) layout.findViewById(R.id.adapter_list_texto);
            view.imagem =                  (ImageView) layout.findViewById(R.id.adapter_list_imagem);

            layout.setTag(view);

        } else {
            view = (ViewHolder) layout.getTag();
        }

        String id_tarefa = listaIds.get(position);

        view.texto.setText("Tarefa id: "+ id_tarefa);

        return layout;
    }

    static class ViewHolder {
        TextView texto;
        ImageView imagem;
    }

}
